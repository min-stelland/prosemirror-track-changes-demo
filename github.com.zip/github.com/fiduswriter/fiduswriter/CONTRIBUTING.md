To get started, <a href="https://cla-assistant.io/fiduswriter/fiduswriter">sign the Contributor License Agreement</a>.
