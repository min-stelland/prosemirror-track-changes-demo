"""
Django application to implement bibliography feature.
"""
