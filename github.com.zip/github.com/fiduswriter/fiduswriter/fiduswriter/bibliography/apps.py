from django.apps import AppConfig


class Config(AppConfig):
    name = "bibliography"
    default_auto_field = "django.db.models.AutoField"
