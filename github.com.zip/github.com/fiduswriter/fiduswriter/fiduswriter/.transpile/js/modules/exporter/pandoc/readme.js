export const readMe =
`Unzip the contents of this file to a folder and convert it then to another format
using pandoc like this:

pandoc document.json -o document.html

Replace "document.html" with other formats you may want.

`
