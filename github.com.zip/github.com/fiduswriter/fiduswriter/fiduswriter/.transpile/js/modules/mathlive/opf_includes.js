// This file is auto-generated. CHANGES WILL BE OVERWRITTEN! Re-generate by running ./manage.py bundle_mathlive.
export const mathliveOpfIncludes = `
<item id="mathlive-0" href="css/mathlive.css" media-type="text/css" />
<item id="mathlive-1" href="css/media/KaTeX_Script-Regular.woff2" media-type="font/woff2" />
<item id="mathlive-2" href="css/media/KaTeX_SansSerif-Italic.woff2" media-type="font/woff2" />
<item id="mathlive-3" href="css/media/KaTeX_Size3-Regular.woff2" media-type="font/woff2" />
<item id="mathlive-4" href="css/media/KaTeX_SansSerif-Bold.woff2" media-type="font/woff2" />
<item id="mathlive-5" href="css/media/KaTeX_Main-Italic.woff2" media-type="font/woff2" />
<item id="mathlive-6" href="css/media/KaTeX_Main-Regular.woff2" media-type="font/woff2" />
<item id="mathlive-7" href="css/media/KaTeX_Math-BoldItalic.woff2" media-type="font/woff2" />
<item id="mathlive-8" href="css/media/KaTeX_SansSerif-Regular.woff2" media-type="font/woff2" />
<item id="mathlive-9" href="css/media/KaTeX_Main-BoldItalic.woff2" media-type="font/woff2" />
<item id="mathlive-10" href="css/media/KaTeX_Math-Italic.woff2" media-type="font/woff2" />
<item id="mathlive-11" href="css/media/KaTeX_Size4-Regular.woff2" media-type="font/woff2" />
<item id="mathlive-12" href="css/media/KaTeX_Typewriter-Regular.woff2" media-type="font/woff2" />
<item id="mathlive-13" href="css/media/KaTeX_Caligraphic-Regular.woff2" media-type="font/woff2" />
<item id="mathlive-14" href="css/media/KaTeX_Size2-Regular.woff2" media-type="font/woff2" />
<item id="mathlive-15" href="css/media/KaTeX_AMS-Regular.woff2" media-type="font/woff2" />
<item id="mathlive-16" href="css/media/KaTeX_Fraktur-Bold.woff2" media-type="font/woff2" />
<item id="mathlive-17" href="css/media/KaTeX_Caligraphic-Bold.woff2" media-type="font/woff2" />
<item id="mathlive-18" href="css/media/KaTeX_Fraktur-Regular.woff2" media-type="font/woff2" />
<item id="mathlive-19" href="css/media/KaTeX_Size1-Regular.woff2" media-type="font/woff2" />
<item id="mathlive-20" href="css/media/KaTeX_Main-Bold.woff2" media-type="font/woff2" />
`