import {setSelection} from "./modules/test_caret/index.js"

const testCaret = {setSelection}

window.testCaret = testCaret
