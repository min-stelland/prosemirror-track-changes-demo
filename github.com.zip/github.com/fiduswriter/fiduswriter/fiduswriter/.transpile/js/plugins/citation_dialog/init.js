// Placeholder for citation dialog plugins
