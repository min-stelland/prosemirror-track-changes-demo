// Placeholder for image plugins
