// Placeholder for app plugins
