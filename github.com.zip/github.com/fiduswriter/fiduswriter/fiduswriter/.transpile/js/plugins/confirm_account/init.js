// placeholder for confirm account plugins
