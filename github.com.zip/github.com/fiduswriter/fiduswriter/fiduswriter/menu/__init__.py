"""
User preferences. no python logic, only frontend.
"""
