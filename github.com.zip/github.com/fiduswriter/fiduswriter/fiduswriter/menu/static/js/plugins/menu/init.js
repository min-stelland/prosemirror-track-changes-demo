// Placeholder for main menu plugins
